#右键执行这个py文件就可以运行了
#主要看qsbk2和pipelines，这里是python3.7。如果用到了库里没装的包，自己装一下，
#图片会下载到pic_down的文件夹下面，xlsx表格会保存到qsbk目录下，每执行一次最好改一下保存的表格名称（在piplines）
#一些细节不好，有需要改的请说明，会改进。
#风景简介在二级子页面，不能和一级页面名称，图片来源一起随yield返回（思考了一晚上未解决。有点菜），所以用了普通爬虫。
#图片下载设置了最久3秒超时会跳过，是为了防止下载图片意外卡死（下载大量图片可能会出现这个问题）


from scrapy import cmdline
import os
def start():
    # cmdline.execute("scrapy
    #
    #
    #
    #
    #
    #
    # crawl qsbk2".split())
    os.system("scrapy crawl qsbk2 -s CLOSESPIDER_TIMEOUT=3600")
    os.system("scrapy crawl baidu -s CLOSESPIDER_TIMEOUT=3600")
    os.system("scrapy crawl weibo -s CLOSESPIDER_TIMEOUT=3600")
    os.system("scrapy crawl xinwen -s CLOSESPIDER_TIMEOUT=3600")

def start2():
    '''百度'''
    os.system("scrapy crawl baidu -s CLOSESPIDER_TIMEOUT=3600")

def start3():
    '''新闻'''
    os.system("scrapy crawl xinwen -s CLOSESPIDER_TIMEOUT=3600")

def start4():
    '''微博'''
    os.system("scrapy crawl weibo -s CLOSESPIDER_TIMEOUT=3600")


if __name__ == '__main__':
    start()



