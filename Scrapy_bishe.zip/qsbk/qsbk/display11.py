import pymysql
from qsbk.spiders.callui import MyMainWindow
def ABC(self):
    db = pymysql.connect(host="localhost",user="root",password="123456",database="minisql")#charset="utf8"
    cur = db.cursor()
    sql = "select * from weibo2"
    try:
        cur.execute(sql)
        db.commit()
    except:
        db.rollback()
    results = cur.fetchall()
    for it in results:
        for i in range(len(it)):
            ''''''
        #     MyMainWindow.printf(self,it[i],' ',end='')
        # MyMainWindow.printf(self,'\n')
    cur.close()
if __name__ == '__main__':
    ABC()
