# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class QsbkItem(scrapy.Item):
    titie = scrapy.Field()
    picture = scrapy.Field()
    content  = scrapy.Field()

class BaiduSpider(scrapy.Item):
    '''百度爬虫'''
    position = scrapy.Field()
    category = scrapy.Field()

class WeiboSpider(scrapy.Item):
    '''微博爬虫'''
    position = scrapy.Field()
    category = scrapy.Field()

class XinwenSpider(scrapy.Item):
    '''中新网爬虫'''
    position = scrapy.Field()
    category = scrapy.Field()
