# from qsbk.spiders.callui import MyMainWindow

import pymysql
def ABC(self):
    print('11111111111111111')

    db = pymysql.connect(host="localhost",user="root",password="123456",database="minisql")#charset="utf8"
    cur = db.cursor()
    sql = "select * from weibo2"
    try:
        cur.execute(sql)
        db.commit()
    except:
        db.rollback()
    results = cur.fetchall()
    for it in results:
        for i in range(len(it)):
            ''''''
            print('2222222222222222')
            # MyMainWindow.printf(Q,it[i],' ',end='')
        # MyMainWindow.printf(self,'\n')
    cur.close()
if __name__ == '__main__':
    print('11111111111111111')
    ABC()
