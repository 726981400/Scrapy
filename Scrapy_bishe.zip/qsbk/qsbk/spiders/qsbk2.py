# -*- coding: utf-8 -*-
import scrapy

from bs4 import BeautifulSoup as BS
import urllib.request
import re
import random
import eventlet
class Qsbk2Spider(scrapy.Spider):
    name = 'qsbk2'
    start_urls = ['http://www.cssn.com.cn/www/hot/']
    def parse(self, response):
        print("开始运行")
        #SelectorList
        Jingdians = response.xpath("/html/body/div[2]/div[1]/div[2]/ul/li")
        eventlet.monkey_patch()
        for Jingdian in Jingdians:
            Jingdian = Jingdian.xpath(".//a").getall()
            content = re.findall('<a href="(.+?)"',str(Jingdian))
            content = str('http://www.cssn.com.cn')+str(content[0])
            page = urllib.request.urlopen(content)
            html = page.read()
            soup = BS(html, "lxml")
            try:
                content = soup.p.text
            except:
                content = 'null'
            picture = re.findall('src="(.+?)"',str(Jingdian))
            if str(picture[0][0])=='h':
                picture = picture[0]
            else:
                picture = str('http://www.cssn.com.cn')+str(picture[0])
            with eventlet.Timeout(3, False):#图片下载，最多3秒延迟
                print(str(picture))
                urllib.request.urlretrieve(str(picture),'..\qsbk\pic_down\%4d.jpg' %(random.randint(0,1000)))
            title = re.findall('<br>(.+?)<',str(Jingdian))[0]
            yield {
                'title':str(title),#景点名称
                'picture':str(picture),#景点图片来源
                'content':str(content)#景点简介
            }













