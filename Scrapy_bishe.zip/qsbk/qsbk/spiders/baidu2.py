
import urllib.request
import re
from bs4 import BeautifulSoup as BS
import datetime
import os
import random
import xlwt
import time
import json
import eventlet
from PyQt5.QtWidgets import QApplication,QMainWindow,QMessageBox
import pymysql
from qsbk.spiders import dHash
# from qsbk.spiders.callui import MyMainWindow

myt1=datetime.datetime.now()
myt2=datetime.datetime.now()

def getHtml(url):
    global my_count
    page = urllib.request.urlopen(url)
    html = page.read()
    # jdata = json.loads(html)
    return html

my_count=0
data_list = []
def get_data_list(html):
    global my_count
    soup=BS(html,"lxml")
    # print(soup)
    x = soup.p.text
    # print(x)
    y1=str(x).replace(" ","")
    y1 =y1.replace("[转载]","转载-")
    print(y1)

    s1=r'\[(.+?)\]'
    s2=re.compile(s1)
    y2=re.findall(s2,y1)
    print(y2)

    y3=y2[1]
    print('2')
    s3=r'\{(.+?)\}'
    s3=re.compile(s3)
    y4=re.findall(s3,y3)
    for i in range(0,len(y4)):
        my_count=my_count+1
        s1=re.compile(r'"objURL":"(.+?)"')
        k1=re.findall(s1,y4[i])
        # print(k1)

        s2=re.compile(r'"fromPageTitle":"(.+?)"')
        k2=re.findall(s2,y4[i])
        s3 = re.compile(r'"fromURL":"(.+?)"')
        k3 = re.findall(s3, y4[i])
        # print(k3)
        s4 = re.compile(r'"bdImgnewsDate":"(.+?)"')
        k4 = re.findall(s4, y4[i])

        s5 = re.compile(r'"type":"(.+?)"')
        k5 = re.findall(s5, y4[i])

        rowdata = [k1, k2, k3, k4, k5]
        data_list.append(rowdata)
    return data_list

def get_excel(data_list):
    # print(5 * '=========')
    # MyMainWindow.printf(5* '========')
    workbook = xlwt.Workbook(encoding='utf-8')
    booksheet = workbook.add_sheet('Sheet 1', cell_overwrite_ok=True)
    rowdata = ['图片url', 'title', '图片来源网址', '图片上传日期', '图片格式']
    col = 0
    for G in range(len(rowdata)):
        col = col + 1
        booksheet.write(0, col, rowdata[G])
    workbook.save('图片信息2.xls')

    # print(len(data_list))
    row = 0
    for i in range(len(data_list)):
        col = 0
        row = row + 1
        rowdata = data_list[i]
        for G in range(len(rowdata)):
            col = col + 1
            booksheet.write(row, col, rowdata[G])
        workbook.save('图片信息2.xls')
    print("所有图片信息保存完毕")

x = 0
y = 0
Error_pic =[]
def getImg(html):

    reg = r'"objURL":"(.*?)",'
    imgre = re.compile(reg)
    html = html.decode('utf-8')
    imglist = re.findall(imgre,html)

    global x
    global y
    global myt1
    global myt2
    for i in imglist:
        # print(i)
        pass
    eventlet.monkey_patch()
    for imgurl in imglist:
        # time.sleep(1)
        # MyMainWindow.printf(imgurl)
        print(imgurl)
        try:
            with eventlet.Timeout(3, False):  # 图片下载，最多3秒延迟
                if str(imgurl).find('.jpg')>=0:
                    urllib.request.urlretrieve(imgurl,'pic_down2\%05d.jpg' %(random.randint(0, 9999)))
                    # print('测试断点5')
                elif str(imgurl).find('.jpeg')>=0:
                    urllib.request.urlretrieve(imgurl,'pic_down2\%05d.jpeg' %(random.randint(10000, 19999)))
                    # print('测试断点6')
                elif str(imgurl).find('.png')>=0:
                    urllib.request.urlretrieve(imgurl,'pic_down2\%05d.png' %(random.randint(20000, 29999)))
                    # print('测试断点7')
                elif str(imgurl).find('.gif') >= 0:
                    urllib.request.urlretrieve(imgurl, 'pic_down2\%05d.gif' % (random.randint(30000, 39999)))
                    # print('测试断点8')
                else:
                    urllib.request.urlretrieve(imgurl,'pic_down2\%05d.jpg' %(random.randint(40000, 49999)))
                    # print('测试断点9')
                x=x+1
                if x % 250 == 1:
                    myt2=datetime.datetime.now()
                    xx0=(myt2-myt1).seconds
                    print("Time" ,x, "==", xx0)


        except:
            pass
            x+=1
            y+=1
            # Error_pic.append(x)
            # print("列表库中第{}张图片=下载失败!!!".format(x))
            # print("共{}张图片下载失败".format(y))
        # print('卡点2：测试断点')
        # h = "pic_down\\"
        # mylistt = os.listdir(h)
        # if (x > 2000):
        #     removePic()
        #     f = "pic_down\\"
        #     mylisttt = os.listdir(f)
        #     s = mylisttt / mylistt * 100
        #     print(s + "%")
        #     x = 0

#图片去重：三层for循环，最外层的for遍历所有文件夹，给图片去重
def removePic():
    x = "pic_down2\\"
    mylist = os.listdir(x)
    pic1 = []
    pic2 = []
    pic3 = []
    pic_Lists = [pic1, pic2, pic3]
    for i in range(len(mylist)):
        x1 = x + mylist[i]
        try:
            fsize1 = os.path.getsize(x1)
            # print(fsize1)
        except:
            continue
        if fsize1 <= 100 * 1024:
            pic1.append(x1)
        elif fsize1 <= 600 * 1024:
            pic2.append(x1)
        else:
            pic3.append(x1)

    # pics为临时列表
    for pic_list in pic_Lists:
        # mylist = os.listdir(mypath)
        for i in range(len(pic_list)):
            # mypath2 = mypath + mylist[i]
            try:
                fsize1 = os.path.getsize(pic_list[i])
            except:
                continue
            for j in range(i + 1, len(pic_list)):
                # mypath3 = mypath + mylist[j]
                try:
                    fsize2 = os.path.getsize(pic_list[j])
                except:
                    continue
                if fsize1 == fsize2:
                    os.remove(pic_list[i])

def ABC():
    print("开始加载")
    db = pymysql.connect(host='localhost', user='root', password='123456', database='minisql')
    cur = db.cursor()
    keyword="超级玛丽"
    key_code = urllib.request.quote(keyword) # 对关键词编码
    s1=r"https://tieba.baidu.com/p/2555125530"
    s2=r'''http://image.baidu.com/search/index?tn=baiduimage&ps=1&ct=201326592&lm=-1&cl=2&nc=1&ie=utf-8&word='''+key_code
    i=0
    # while True:s
    while i<1:
        page_number=i
        s3=r'''http://image.baidu.com/search/avatarjson?tn=resultjsonavatarnew&ie=utf-8&word=''' + key_code + "&cg=girl&rn=60&pn=" + str(page_number)
        print(s3)
        #1.整合网页信息
        try:
            print('卡点1：获取网页')
            html = getHtml(s3)
        except:
            print("连接失败，请检查网络是否可用...")
            break
        # print('下载网页')
        # with open("html.txt","w") as f:
        #     f.write(str(html))
        # print('下载完成')

        #2.加载图片5项信息
        print("卡点2：加载图片信息")
        data_list = get_data_list(html)
        for i in range(len(data_list)):
            sql = "insert into baidu2 value (%s,%s,%s,%s,%s,%s)"
            try:
                parm = str(i)
                parm2 = (data_list[i][0])
                parm3 = (data_list[i][1])
                parm4 = (data_list[i][2])
                num5 = (data_list[i][3])
                num6 = (data_list[i][4])


                # print(i, parm, parm2,parm3,parm4,num5,num6)
                try:
                    cur.execute(sql, (parm, parm2, parm3, parm4, num5, num6))
                    db.commit()
                    print(i)
                    print('导入数据库成功')

                except:
                    print("导入数据库失败")
                    db.rollback()
            except:
                ''''''
        cur.close()
        #3.下载图片至本地
        print('卡点3：下载图片到本地')
        getImg(html)
    #
        # 4.图片去重
        removePic()
    #
        # 翻页
        print('翻页')
        i=i+1
    #
        print("**"*10)
        print("第{}页图片下载完毕".format(i))
        print("第{}页图片去重结束".format(i))
        print("**" * 10)


        if x>2600:
            break
    #保存图片信息至xls表格
    try:
        print('卡点4：图片信息保存到表格')
        get_excel(data_list)
    except:
        pass

    # print("下载失败图片序号如下：{}".format(Error_pic))
    #
    # print("finish!","!!!!"*10)

def ABC2(self,keyword):
    keyword="灾害"
    key_code = urllib.request.quote(keyword) # 对关键词编码
    s1=r"https://tieba.baidu.com/p/2555125530"
    s2=r'''http://image.baidu.com/search/index?tn=baiduimage&ps=1&ct=201326592&lm=-1&cl=2&nc=1&ie=utf-8&word='''+key_code
    i=0
    # while True:
    while i<1:
        page_number=i
        s3=r'''http://image.baidu.com/search/avatarjson?tn=resultjsonavatarnew&ie=utf-8&word=''' + key_code + "&cg=girl&rn=60&pn=" + str(page_number)
        print(s3)
        try:
            html = getHtml(s3)
            print('getHtml成功执行')
        except:
            print("被反爬了")
            QMessageBox.information( self,"信息提示框", "连接失败，请检查网络是否可用。")
            break

        try:
            data_list = get_data_list(html)
            print("get_data_list()执行成功")
        except:
            print('保存数据出错了')
            pass
        try:
            db = pymysql.connect(host='localhost', user='root', password='123456', database='minisql')
            cur = db.cursor()
            for i in range(len(data_list)):
                sql = "insert into baidu2 value (%s,%s,%s,%s,%s,%s)"

                parm = str(random.randint(0,100000))
                parm2 = (data_list[i][0])
                parm3 = str((data_list[i][1]))
                parm4 = (data_list[i][2])
                num5 = (data_list[i][3])
                num6 = (data_list[i][4])
                print(parm, parm2,parm3,parm4,num5,num6)
                try:
                    cur.execute(sql, (parm, parm2, parm3, parm4, num5, num6))
                    db.commit()
                    print(i)
                    print('导入数据库成功')

                except:
                    print("导入数据库失败")
                    db.rollback()

            cur.close()
        except:
            print('保存数据库失败')

        try:
            getImg(html)
            print("图片下载完成")
        except:
            print("图片下载出错了")
            pass

        # removePic()

        i=i+1

    try:
        get_excel(data_list)
        print('表格保存完毕')
    except:
        pass

if __name__ == '__main__':
    ABC()
    print('加载完毕')

