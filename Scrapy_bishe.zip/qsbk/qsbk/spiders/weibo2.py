# encoding :utf-8

import urllib.request
import requests
from bs4 import BeautifulSoup
import re
import time
import datetime
import os
import xlwt
from PyQt5.QtWidgets import QApplication,QMainWindow,QMessageBox
import html5lib
import csv
import json
import pymongo
import random
import eventlet
# from qsbk.spiders.callui import MyMainWindow
import pymysql

weibos = []
tupians = []
def parse_page(url):
    global  x
    x = 1
    headers = {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 UBrowser/6.2.4094.1 Safari/537.36',
                # 'Cookie' : 'SINAGLOBAL=9090973275525.982.1553165732687; login_sid_t=3670dc77dd5ae00fc968a950984f1724; cross_origin_proto=SSL; Ugrow-G0=169004153682ef91866609488943c77f; YF-V5-G0=1312426fba7c62175794755e73312c7d; WBStorage=201904251357|undefined; _s_tentry=www.baidu.com; UOR=,,www.baidu.com; wb_view_log=1366*7681; Apache=3541685836206.7114.1556171993362; ULV=1556171993422:3:2:1:3541685836206.7114.1556171993362:1555040226154; SUB=_2A25xxTwHDeRhGeBG6VcY8SjFwj2IHXVSsyrPrDV8PUNbmtBeLXfnkW9NRgnoMGrgFiSZnb8vsplg5i781bENE4zq; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFQT99oapfbhqHIbNi0HEux5JpX5KzhUgL.FoqReo-4eKq41K22dJLoIEBLxK-L1KnL1h5LxK-L1KML1KzLxK-L12qLB--LxK.L1KeL1het; SUHB=0ElK9pXjWg3Dpe; ALF=1587707863; SSOLoginState=1556171864; wvr=6; YF-Page-G0=da1eb9ea7ccc47f9e865137ccb4cf9f3|1556171874|1556171874; wb_view_log_6825916991=1366*7681; webim_unReadCount=%7B%22time%22%3A1556172034705%2C%22dm_pub_total%22%3A0%2C%22chat_group_pc%22%3A0%2C%22allcountNum%22%3A8%2C%22msgbox%22%3A0%7D'
                # 'Cookie': 'SINAGLOBAL=5723398216986.073.1583811792523; login_sid_t=aefbe15ddffde681115bef672c7753cd; cross_origin_proto=SSL; Ugrow-G0=7e0e6b57abe2c2f76f677abd9a9ed65d; YF-V5-G0=f5a079faba115a1547149ae0d48383dc; WBStorage=42212210b087ca50|undefined; _s_tentry=weibo.com; Apache=532632976067.93933.1590428633986; wb_view_log=1366*7681; ULV=1590428634241:8:3:1:532632976067.93933.1590428633986:1589988315552; crossidccode=CODE-yf-1JDh3q-29rFAk-WoDk3EzxzChjcaza1ba2a; ALF=1621964324; SSOLoginState=1590428325; SUB=_2A25zyHL1DeRhGeBO6lcR8CnNyj2IHXVQvOM9rDV8PUNbmtCOLXetkW9NSiCLixJDYM3g9AKzXILhd7dFifIzhjql; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFiipuIyuwTlDspP1UyRoCM5JpX5KzhUgL.Foq7eK-7ehMpeK22dJLoI7yyqg4VIgfyd5tt; SUHB=0nleCi3-cu7Ze6; wvr=6; UOR=search.sina.com.cn,s.weibo.com,graph.qq.com; wb_view_log_6015007111=1366*7681; YF-Page-G0=afcf131cd4181c1cbdb744cd27663d8d|1590428330|1590428330; webim_unReadCount=%7B%22time%22%3A1590428706121%2C%22dm_pub_total%22%3A6%2C%22chat_group_client%22%3A0%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A6%2C%22msgbox%22%3A0%7D'
        # 'Cookie': 'SINAGLOBAL=5723398216986.073.1583811792523; wvr=6; Ugrow-G0=5c7144e56a57a456abed1d1511ad79e8; login_sid_t=d4b872c026761e33bacf78066c306d24; cross_origin_proto=SSL; YF-V5-G0=bae6287b9457a76192e7de61c8d66c9d; WBStorage=42212210b087ca50|undefined; wb_view_log=1366*7681; _s_tentry=passport.weibo.com; Apache=7593057139068.38.1590670108293; ULV=1590670108300:11:6:4:7593057139068.38.1590670108293:1590478503250; crossidccode=CODE-yf-1JEhXz-29rI5K-bk9vJKTttx7oEqNee7eb0; ALF=1622206131; SSOLoginState=1590670133; SCF=ApHDFIFelVal57MoUJ_WNaJoowcTwYOqmx6epg4x3RtEA5r-YmZUFoIqH3hkxCZ2pHyeA8jiT0CHdUFrBL7t8Vc.; SUB=_2A25zy8NlDeRhGeBO6lcR8CnNyj2IHXVQoLOtrDV8PUNbmtANLWHgkW9NSiCLi4IVlmEG97LIdIJip_6N6UmrSX3H; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFiipuIyuwTlDspP1UyRoCM5JpX5KzhUgL.Foq7eK-7ehMpeK22dJLoI7yyqg4VIgfyd5tt; SUHB=0xnyq_3SVuCmBh; UOR=search.sina.com.cn,s.weibo.com,graph.qq.com; YF-Page-G0=6eec770a43f9cb16c2cfc71cfe5ac8df|1590670140|1590670140; wb_view_log_6015007111=1366*7681; webim_unReadCount=%7B%22time%22%3A1590670141280%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A0%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A0%2C%22msgbox%22%3A0%7D'
        # 'Cookie': 'SINAGLOBAL=5723398216986.073.1583811792523; wvr=6; login_sid_t=82f9829f0eaf926a781231eb2a064992; cross_origin_proto=SSL; _s_tentry=passport.weibo.com; Apache=7002715009175.922.1590829054764; ULV=1590829054810:12:7:5:7002715009175.922.1590829054764:1590670108300; ALF=1622365072; SSOLoginState=1590829073; SCF=ApHDFIFelVal57MoUJ_WNaJoowcTwYOqmx6epg4x3RtErgHCgh2ZaxO5DjPd_5Ix9LmYFatLDF11VyovmcK930Q.; SUB=_2A25z1lBCDeRhGeBO6lcR8CnNyj2IHXVQosaKrDV8PUNbmtANLWrQkW9NSiCLi5ql6hp_l6OqqcgPCxGRNDKzIuTo; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFiipuIyuwTlDspP1UyRoCM5JpX5KzhUgL.Foq7eK-7ehMpeK22dJLoI7yyqg4VIgfyd5tt; SUHB=0ftZogifSYwWBI; UOR=search.sina.com.cn,s.weibo.com,www.baidu.com; webim_unReadCount=%7B%22time%22%3A1590845393587%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A0%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A0%2C%22msgbox%22%3A0%7D; WBStorage=42212210b087ca50|undefined'
        # 'Cookie': 'SINAGLOBAL=5723398216986.073.1583811792523; Ugrow-G0=6fd5dedc9d0f894fec342d051b79679e; login_sid_t=0353d565805c99560d37616090f882f5; cross_origin_proto=SSL; YF-V5-G0=f0aacce81fff76e1515ae68ac76a20c3; wb_view_log=1366*7681; _s_tentry=passport.weibo.com; Apache=3686625033544.284.1591105959371; ULV=1591105959378:14:1:2:3686625033544.284.1591105959371:1590925189107; ALF=1622641980; SSOLoginState=1591105982; SCF=ApHDFIFelVal57MoUJ_WNaJoowcTwYOqmx6epg4x3RtEMbWa-GNCs3prQZrFT8BklVhP_a2Rbk0x1PCz_CJh7cQ.; SUB=_2A25z0inuDeRhGeBO6lcR8CnNyj2IHXVQphwmrDV8PUNbmtANLUvxkW9NSiCLixM9nsk2sgPJrLHgaiuZn2zgLjNr; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFiipuIyuwTlDspP1UyRoCM5JpX5KzhUgL.Foq7eK-7ehMpeK22dJLoI7yyqg4VIgfyd5tt; SUHB=0rrL1aCY1dH8SC; wvr=6; UOR=search.sina.com.cn,s.weibo.com,graph.qq.com; wb_view_log_6015007111=1366*7681; YF-Page-G0=57faaa171019ffa4cbeb35c54dccf2dc|1591106081|1591105987; webim_unReadCount=%7B%22time%22%3A1591109623856%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A0%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A0%2C%22msgbox%22%3A0%7D'
        'Cookie': 'SINAGLOBAL=5723398216986.073.1583811792523; Ugrow-G0=6fd5dedc9d0f894fec342d051b79679e; login_sid_t=0353d565805c99560d37616090f882f5; cross_origin_proto=SSL; YF-V5-G0=f0aacce81fff76e1515ae68ac76a20c3; _s_tentry=passport.weibo.com; Apache=3686625033544.284.1591105959371; ULV=1591105959378:14:1:2:3686625033544.284.1591105959371:1590925189107; wb_view_log_6015007111=1366*7681; WBStorage=42212210b087ca50|undefined; wb_view_log=1366*7681; crossidccode=CODE-yf-1JGhlE-29rI6m-uOLyJ4lATEiMo7Df22853; ALF=1622680425; SSOLoginState=1591144425; SCF=ApHDFIFelVal57MoUJ_WNaJoowcTwYOqmx6epg4x3RtEU5tJ5gOTSySSqauH2QjfZRPm7WLXI3ENQnrPDlt4Xxw.; SUB=_2A25z0p-5DeRhGeBO6lcR8CnNyj2IHXVQqfZxrDV8PUNbmtCOLWbbkW9NSiCLi0DGH9l2FlxnjAJ8OQDX69nD3KC_; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFiipuIyuwTlDspP1UyRoCM5JpX5KzhUgL.Foq7eK-7ehMpeK22dJLoI7yyqg4VIgfyd5tt; SUHB=0k1yeF_ptcK9K0; wvr=6; YF-Page-G0=72c3755f0b696b630e54724e16f8cb83|1591144430|1591144384; UOR=search.sina.com.cn,s.weibo.com,graph.qq.com; webim_unReadCount=%7B%22time%22%3A1591144440940%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A0%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A0%2C%22msgbox%22%3A0%7D'
    }

    response = requests.get(url,headers=headers)
    text=response.text
    # 解决中文乱码
    soup = BeautifulSoup(text,'html5lib')
    # print(soup)

    weiboneirong=soup.find('div',class_="m-con-l")


#获取评论信息
    pinluns=[]
    get_pinlun = soup.find_all('div',class_="txt")
    for pinlun in get_pinlun:
        pinlun = pinlun.getText()
        # print(comment)
        pinlun = pinlun.replace('\n','')
        pinlun = pinlun.replace(' ','')
        pinluns.append(pinlun)
    # print(pinluns)


    #获取博主信息
    authors=[]
    get_authors = re.findall(r'<div class="info">.*?<div>.*?<div>.*?<a.*?>(.*?)</a>', str(weiboneirong), re.DOTALL)
    for author in get_authors:
        author = re.sub(r'<.*?>', '', author, re.DOTALL)
        authors.append(author)
    # print(authors)

    #获取图片
    # tupians = []
    get_tupians = re.findall(r'<li>.*?src="(//ww.*?.jpg)".*?</li>', str(weiboneirong), re.DOTALL)
    # print(get_tupians)
    for i in get_tupians:
        tupians.append(i)
    # print(tupians)
    # print(get_tupians)


    # 获取微博内容
    comments=[]
    get_comment = weiboneirong.find_all('p', class_='txt')
    # get_comment=str(get_comment)
    # print(get_comment)
    for comment in get_comment:
        comment = comment.getText()
        # print(comment)
        comment = comment.replace('\n','')
        comment = comment.replace(' ','')
        comments.append(comment)
    # print(comments)

    # 获取微博来源
    laiyuans= []
    get_laiyuan = weiboneirong.find_all('p', class_='from')
    # print(get_comment)
    # print('***'*20)
    for laiyuan in get_laiyuan:
        laiyuan = laiyuan.getText()
        laiyuan = laiyuan.replace('\n','')
        laiyuan = laiyuan.replace(' ','')
        laiyuans.append(laiyuan)
    # print(laiyuans)

#获取微博的转发数
    zhuanfashus = re.findall(r'<div class="card-act">.*?<a.*?>.*?<a.*?>(.*?)</a>', str(weiboneirong), re.DOTALL)
    # print(zhuanfashus)
#获取微博的评论数量
    pinlunshus =re.findall(r'<div class="card-act">.*?<a.*?>.*?<a.*?>.*?<a.*?>(.*?)</a>', str(weiboneirong), re.DOTALL)
    # print(pinlunshus)
#获取微博的点赞数量
    dianzanshus = re.findall(r'<i class="icon-act icon-act-praise">.*?<em>(.*?)</em>',str(weiboneirong),re.DOTALL)
    # print(dianzanshus)


#把前面所获取到的数据加入到weibos列表中
    for value in zip(authors,get_tupians,comments,laiyuans,zhuanfashus,pinlunshus,dianzanshus):
        author,tupian,comment,laiyuan,zhuanfashu,pinlunshu,dianzanshu = value
        weibo = [author,comment,tupian,laiyuan,zhuanfashu,pinlunshu,'点赞'+dianzanshu]
        # print(weibo)
        # print('***'*30)
        weibos.append(weibo)
    # print(weibos)

#设置爬取每页的休眠时间，防止爬取太快封ip
    time.sleep(1)
#将获取到的数据返回，以便保存函数调用
    return weibos


def getImg():
    eventlet.monkey_patch()
    for imgurl in tupians:
        # print(imgurl)
        # MyMainWindow.printf(imgurl)
        with eventlet.Timeout(3, False):  # 图片下载，最多3秒延迟
            # urllib.request.urlretrieve('http:'+imgurl, 'pic_down4\%05d.jpg' % (random.randint(0, 9999)))
            try:
                ''''''
                urllib.request.urlretrieve('http:'+imgurl,'pic_down4\%05d.jpg' %(random.randint(0, 9999)))
            except:
                pass

# 把weibos中的数据存入到Excel表中
def getExcel(weibos):
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet('微博爬虫')
    worksheet.write(0, 0, '博主')
    worksheet.write(0, 1, '内容')
    worksheet.write(0, 2, '图片')
    worksheet.write(0, 3, '来源')
    worksheet.write(0, 4, '转发数')
    worksheet.write(0, 5, '评论数')
    worksheet.write(0, 6, '点赞数')
    row = 0
    for i in range(len(weibos)):
        # if len(weibos[i + 1]) > 1:
        weiboo = weibos[i]
        col = 0
        row = row + 1
        for m in range(len(weiboo)):
            worksheet.write(row, col, weiboo[m])
            col = col +1
    workbook.save( '微博信息2.xls')

#图片去重：三层for循环，最外层的for遍历所有文件夹，给图片去重
def removePic():
    x = "pic_down4\\"
    mylist = os.listdir(x)
    pic1 = []
    pic2 = []
    pic3 = []
    pic_Lists = [pic1, pic2, pic3]
    for i in range(len(mylist)):
        x1 = x + mylist[i]
        try:
            fsize1 = os.path.getsize(x1)
            # print(fsize1)
        except:
            continue
        if fsize1 <= 100 * 1024:
            pic1.append(x1)
        elif fsize1 <= 600 * 1024:
            pic2.append(x1)
        else:
            pic3.append(x1)

    # pics为临时列表
    for pic_list in pic_Lists:
        # mylist = os.listdir(mypath)
        for i in range(len(pic_list)):
            # mypath2 = mypath + mylist[i]
            try:
                fsize1 = os.path.getsize(pic_list[i])
            except:
                continue
            for j in range(i + 1, len(pic_list)):
                # mypath3 = mypath + mylist[j]
                try:
                    fsize2 = os.path.getsize(pic_list[j])
                except:
                    continue
                if fsize1 == fsize2:
                    try:
                        os.remove(pic_list[i])
                    except:
                        pass


def ABC():
    i = 0
    # while True:
    for i in range(1, 5):
        keyword = "灾害"
        key_code = urllib.request.quote(keyword)  # 对关键词编码
        try:
            url = 'https://s.weibo.com/weibo?q='+key_code+'&wvr=6&Refer=SWeibo_box&page='+(str(i))
            weibos =parse_page(url)
        except:
            pass
        i += 1
    try:
        getImg()
        getExcel(weibos)
    except:
        print("加载失败，请检查网络设置或者稍后重试")
    print("查询结束，退出彩虹引擎")

def ABC2(self,keyword):
    i = 0
    key_code = urllib.request.quote(keyword)  # 对关键词编码
    db = pymysql.connect(host='localhost', user='root', password='123456', database='minisql')
    cur = db.cursor()
    # while True:
    for i in range(1, 3):
        try:
            url = 'https://s.weibo.com/weibo?q=' + key_code + '&wvr=6&Refer=SWeibo_box&page=' + (str(i))
            # MyMainWindow.printf(url)
            weibos = parse_page(url)
            print('抓取网页成功')
        except:
            pass
        i += 1

    for i in range(len(weibos)):
        sql = "insert into weibo2 value (%s,%s,%s,%s,%s,%s,%s)"
        try:
            parm = str(i) + (weibos[i][0])
            parm2 = (weibos[i][1])
            parm3 = (weibos[i][2])
            parm4 = (weibos[i][3])
            num5 = (weibos[i][4])
            num6 = (weibos[i][5])
            num7 = (weibos[i][6])

            # print(i, parm, parm2,parm3,parm4,num5,num6,num7)
            try:
                cur.execute(sql,(parm, parm2,parm3,parm4,num5,num6,num7))
                db.commit()
                print('导入数据库成功')

            except:
                print("导入数据库失败")
                db.rollback()

        except:
            pass

    try:
        ''''''
        getImg()
        getExcel(weibos)
        print('下载图片成功')
        print('保存表格成功')
    except:
        print("加载失败，请检查网络设置或者稍后重试")
        QMessageBox.information(self, "信息提示框", "加载失败，请检查网络设置或者稍后重试")
    try:
        removePic()
    except:
        print('删除失败')
    print("查询结束，退出彩虹引擎")

if __name__ == '__main__':
    ABC()
