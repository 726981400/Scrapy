# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(290, 423)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(0, 0, 291, 381))
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.frame.setStyleSheet("\n"
                                 "image: url(./images/image2.png);")
        self.pushButton = QtWidgets.QPushButton(self.frame)
        self.pushButton.setGeometry(QtCore.QRect(10, 80, 75, 23))
        self.pushButton.setObjectName("百度查询")
        self.pushButton_2 = QtWidgets.QPushButton(self.frame)
        self.pushButton_2.setGeometry(QtCore.QRect(100, 80, 75, 23))
        self.pushButton_2.setObjectName("中新网查询")
        self.pushButton_3 = QtWidgets.QPushButton(self.frame)
        self.pushButton_3.setGeometry(QtCore.QRect(190, 80, 75, 23))
        self.pushButton_3.setObjectName("微博查询")
        self.pushButton_4 = QtWidgets.QPushButton(self.frame)
        self.pushButton_4.setGeometry(QtCore.QRect(10, 110, 75, 23))
        self.pushButton_4.setObjectName("百度模块SQL")
        self.pushButton_5 = QtWidgets.QPushButton(self.frame)
        self.pushButton_5.setGeometry(QtCore.QRect(100, 110, 75, 23))
        self.pushButton_5.setObjectName("中新网模块SQL")
        self.pushButton_6 = QtWidgets.QPushButton(self.frame)
        self.pushButton_6.setGeometry(QtCore.QRect(190, 110, 75, 23))
        self.pushButton_6.setObjectName("微博模块SQL")
        self.pushButton_7 = QtWidgets.QPushButton(self.frame)
        self.pushButton_7.setGeometry(QtCore.QRect(100, 140, 75, 23))
        self.pushButton_7.setObjectName("")
        self.lineEdit = QtWidgets.QLineEdit(self.frame)
        self.lineEdit.setGeometry(QtCore.QRect(80, 40, 113, 21))
        self.lineEdit.setObjectName("lineEdit")
        # self.listView = QtWidgets.QListView(self.frame)
        # self.listView.setGeometry(QtCore.QRect(10, 180, 256, 192))
        # self.listView.setObjectName("listView")
        self.textBrowser = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser.setGeometry(QtCore.QRect(10, 180, 266, 190))
        self.textBrowser.setObjectName("textBrowser")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 290, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "信息采集系统"))
        self.pushButton.setText(_translate("MainWindow", "百度采集"))
        self.pushButton_2.setText(_translate("MainWindow", "中新网采集"))
        self.pushButton_3.setText(_translate("MainWindow", "微博采集"))
        self.pushButton_4.setText(_translate("MainWindow", "百度sql查询"))
        self.pushButton_5.setText(_translate("MainWindow", "新闻sql查询"))
        self.pushButton_6.setText(_translate("MainWindow", "微博sql查询"))
        self.pushButton_7.setText(_translate("MainWindow", "使用说明"))

