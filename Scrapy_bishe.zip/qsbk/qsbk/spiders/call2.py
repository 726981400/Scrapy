import sys
import uuid
import decimal
from PyQt5.QtWidgets import QApplication,QMainWindow,QMessageBox
# from qsbk.spiders.baiduspider import Qsbk2Spider
from qsbk.spiders import baidu2,weibo2,xinwen2
from qsbk.spiders import display1
from qsbk.spiders import dHash
from qsbk.spiders import untitled
import start
from PyQt5.QtCore import pyqtSignal,Qt
import datetime
import time
import pymysql
from qsbk.spiders import 测试1
from PyQt5.QtGui import QIcon

class MyForm(QMainWindow, 测试1.Ui_MainWindow):

    def __init__(self,parent=None):
        super(MyForm, self).__init__(parent)
        # self.setStyleSheet('#Form{background-color:#ffffff;}')
        self.setupUi(self)
        self.initUI()
        MyForm.printf(self,time.strftime('%Y-%m-%d %H:%M:%S'))


    def initUI(self):
        self.setWindowIcon(QIcon('images/ico.ico'))
        self.pushButton.clicked.connect(self.showsth)
        self.pushButton_2.clicked.connect(self.showsth2)
        self.pushButton_3.clicked.connect(self.showsth3)
        self.pushButton_4.clicked.connect(self.showsth4)
        self.pushButton_5.clicked.connect(self.showsth5)
        self.pushButton_6.clicked.connect(self.showsth6)
        self.pushButton_7.clicked.connect(self.showsth7)


    def printf(self, mes):
        self.textBrowser.append(mes)  # 在指定的区域显示提示信息
        self.cursot = self.textBrowser.textCursor()
        self.textBrowser.moveCursor(self.cursot.End)

    #百度引擎
    def showsth(self):
        keyword = self.lineEdit.text()
        if keyword == "":
            QMessageBox.information(self, "信息提示框", "未输入关键字，将默认采集灾害数据")
            MyForm.printf(self,'未输入关键字，将默认采集灾害数据')

            start.start2()
            # dHash.main()
            MyForm.printf(self,'页面抓取完成')
            MyForm.printf(self,'数据爬取完成')
            MyForm.printf(self,'数据已存储到表格')
            MyForm.printf(self,'图片下载完成')
            # MyForm.printf(self,'克隆完成，请数据在本地查看')
            # MyForm.printf(self, time.strftime('%Y-%m-%d %H:%M:%S'))

        else:
            QMessageBox.information(self, "信息提示框", "将默认采集"+keyword+"数据")

            MyForm.printf(self, "将默认采集->"+keyword+"<-数据")
            baidu2.ABC2(self,keyword)
            # dHash.main()
            MyForm.printf(self,'克隆完成,请在本地查看')
            print("执行完毕")

            QMessageBox.information(self, "信息提示框", "克隆完成，请在本地文件夹查看")
            MyForm.printf(self, '百度模块（关键字）执行完毕')
            MyForm.printf(self, time.strftime('%Y-%m-%d %H:%M:%S'))

        # sys.exit()

    #中新网引擎
    def showsth2(self):
        keyword = self.lineEdit.text()

        QMessageBox.information(self, "信息提示框", "新闻模块默认采集数据")
        xinwen2.ABC()
        MyForm.printf(self, '页面抓取完成')
        MyForm.printf(self, '数据爬取完成')
        MyForm.printf(self,'克隆完成，请在本地查看')
        MyForm.printf(self,time.strftime('%Y-%m-%d %H:%M:%S'))




        # sys.exit()

    #微博引擎
    def showsth3(self):
        keyword = self.lineEdit.text()
        if keyword == "":
            QMessageBox.information(self, "信息提示框", "未输入关键字，将默认采集灾害数据")
            start.start4()
            MyForm.printf(self, '页面抓取完成')
            MyForm.printf(self, '数据爬取完成')
            MyForm.printf(self, '数据已存储到表格')
            MyForm.printf(self, '图片下载完成')
            MyForm.printf(self, '克隆完成，请数据在本地查看')
            MyForm.printf(self, time.strftime('%Y-%m-%d %H:%M:%S'))

            # dHash.main()

        else:
            QMessageBox.information(self, "信息提示框", "将默认采集"+keyword+"数据")
            weibo2.ABC2(self,keyword)
            # dHash.main()
            QMessageBox.information(self, "信息提示框", "克隆完成，请在本地文件夹查看")
            MyForm.printf(self, '微博模块（关键字）执行完毕')
            MyForm.printf(self, time.strftime('%Y-%m-%d %H:%M:%S'))

        # sys.exit()

    #热门查询引擎
    def showsth4(self):
        ''''''
        db = pymysql.connect(host="localhost", user="root", password="123456", database="minisql")  # charset="utf8"
        cur = db.cursor()
        sql = "select * from baidu2"
        try:
            cur.execute(sql)
            db.commit()
        except:
            db.rollback()
        results = cur.fetchall()
        for it in results:
            for i in range(len(it)):
                ''''''
                MyForm.printf(self, it[i]+'\n')
        cur.close()
        MyForm.printf(self, time.strftime('%Y-%m-%d %H:%M:%S'))

    def showsth5(self):
        ''''''
        db = pymysql.connect(host="localhost", user="root", password="123456", database="minisql")  # charset="utf8"
        cur = db.cursor()
        sql = "select * from a4"
        try:
            cur.execute(sql)
            db.commit()
        except:
            db.rollback()
        results = cur.fetchall()
        for it in results:
            for i in range(len(it)):
                ''''''
                MyForm.printf(self,it[i])
        cur.close()
        MyForm.printf(self,time.strftime('%Y-%m-%d %H:%M:%S'))

    def showsth6(self):
        ''''''
        db = pymysql.connect(host="localhost", user="root", password="123456", database="minisql")  # charset="utf8"
        cur = db.cursor()
        sql = "select * from weibo2"
        try:
            cur.execute(sql)
            db.commit()
        except:
            db.rollback()
        results = cur.fetchall()
        for it in results:
            for i in range(len(it)):
                ''''''
                MyForm.printf(self, it[i])
        cur.close()
        MyForm.printf(self, time.strftime('%Y-%m-%d %H:%M:%S'))

    def showsth7(self):
        ''''''
        QMessageBox.information(self, "信息提示框",

                                "欢迎使用采集搜索引擎，"
                                "\n"
                                "采集搜索引擎的对应的pic_down文件夹，"
                                "\n"
                                "用以存放克隆的图片。"
                                "\n"
                                "对应的‘图片信息.xls’表格文件自动生成在同级文件夹"
                                "\n"
                                "如果克隆图片失败，"
                                "\n"
                                "请更换关键字或者检查网络后再试。")
        # sys.exit()

if __name__ == '__main__':

    app = QApplication(sys.argv)
    win = MyForm()
    win.show()
    sys.exit(app.exec_())
