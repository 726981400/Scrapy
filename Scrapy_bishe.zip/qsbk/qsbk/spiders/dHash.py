import os
from PIL import Image

class DHash(object):

    @staticmethod
    def calculate_hash(image):
        difference = DHash.__difference(image)
        # 转化为16进制(每个差值为一个bit,每8bit转为一个16进制)
        decimal_value = 0
        hash_string = ""
        for index, value in enumerate(difference):
            if value:  # value为0, 不用计算, 程序优化
                decimal_value += value * (2 ** (index % 8))
            if index % 8 == 7:  # 每8位的结束
                hash_string += str(hex(decimal_value)[2:].rjust(2, "0"))  # 不足2位以0填充。0xf=>0x0f
                decimal_value = 0
        # print(hash_string)
        return hash_string

    @staticmethod
    def hamming_distance(first, second):

        # A. dHash值计算汉明距离
        if isinstance(first, str):
            return DHash.__hamming_distance_with_hash(first, second)

        # B. image计算汉明距离
        hamming_distance = 0
        image1_difference = DHash.__difference(first)
        image2_difference = DHash.__difference(second)
        for index, img1_pix in enumerate(image1_difference):
            img2_pix = image2_difference[index]
            if img1_pix != img2_pix:
                hamming_distance += 1
        # print(hamming_distance)
        return hamming_distance

    @staticmethod
    def __difference(image):

        resize_width = 9
        resize_height = 8
        # 1. resize to (9,8)
        smaller_image = image.resize((resize_width, resize_height))
        # 2. 灰度化 Grayscale
        grayscale_image = smaller_image.convert("L")
        # 3. 比较相邻像素
        pixels = list(grayscale_image.getdata())
        difference = []
        for row in range(resize_height):
            row_start_index = row * resize_width
            for col in range(resize_width - 1):
                left_pixel_index = row_start_index + col
                difference.append(pixels[left_pixel_index] > pixels[left_pixel_index + 1])
        return difference

    @staticmethod
    def __hamming_distance_with_hash(dhash1, dhash2):

        difference = (int(dhash1, 16)) ^ (int(dhash2, 16))
        return bin(difference).count("1")


def main():
    print("开始去重")
    #当汉明距离小于5的时候，判定为相似图片，予以处理
    x =os.listdir("pic_down\\")
    hash_list = []
    img_list = []

    #hash值列表
    for i in range(len(x)):
        try:
            a = Image.open("pic_down\\"+x[i])
        except:
            pass
        hash_list.append(a)
    #图片路径列表
    for j in range(len(x)):
        j = "pic_down\\"+x[j]
        img_list.append(j)

    for m in range(len(hash_list)-1):
        img0hash = hash_list[m]
        mypath0 = img_list[m]
        for n in range(m+1,len(hash_list)):
            img1hash = hash_list[n]
            mypath1 = img_list[n]
            distance = DHash.hamming_distance(img0hash,img1hash)
            # print(distance)
            if distance<5:
                # print(distance)
                # os.remove(mypath1)
                try:
                    os.remove(mypath1)
                    print("移除"+mypath1+"成功")
                except:
                    pass
    print("执行结束")

if __name__ == '__main__':
    main()

