import os

def removePic():
    x = "pic_down3\\"
    mylist = os.listdir(x)
    print(mylist)
    pic1 = []
    pic2 = []
    pic3 = []
    pic_Lists = [pic1, pic2, pic3]
    for i in range(len(mylist)):
        x1 = x + mylist[i]
        try:
            fsize1 = os.path.getsize(x1)
            # print(fsize1)
        except:
            continue
        if fsize1 <= 100 * 1024:
            pic1.append(x1)
        elif fsize1 <= 600 * 1024:
            pic2.append(x1)
        else:
            pic3.append(x1)

    # pics为临时列表
    for pic_list in pic_Lists:
        # mylist = os.listdir(mypath)
        for i in range(len(pic_list)):
            # mypath2 = mypath + mylist[i]
            try:
                fsize1 = os.path.getsize(pic_list[i])
            except:
                continue
            for j in range(i + 1, len(pic_list)):
                # mypath3 = mypath + mylist[j]
                try:
                    fsize2 = os.path.getsize(pic_list[j])
                except:
                    continue
                if fsize1 == fsize2:
                    print(fsize2)
                    try:
                        os.remove(pic_list[i])
                    except:
                        pass

if __name__ == '__main__':
    removePic()
    # os.remove(pic_list[i])