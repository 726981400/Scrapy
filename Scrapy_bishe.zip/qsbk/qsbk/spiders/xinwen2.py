import requests
import urllib
from bs4 import BeautifulSoup as BS
from lxml import html
etree = html.etree
import re
import time
import pymysql


url_list = []
tt_list = []#类别和主题
type = []
title = []
def getHtml(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
        'Referer':'http: // sou.chinanews.com / imgsearch.do'
    }

    respons = requests.get(url, headers=headers )
    respons.encoding='utf-8'
    html = respons.text
    soup = BS(html, 'lxml')
    a_list = soup.select('#content_right > div.content_list > ul>li')
    return a_list

def getHtml2(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
        # 'Referer':'http: // sou.chinanews.com / imgsearch.do'
    }
    respons = requests.get(url, headers=headers )
    respons.encoding='utf-8'
    html = respons.text
    soup = BS(html, 'lxml')
    p = soup.select('#cont_1_1_2 > div.left_zw')
    p = str(p)
    return p

def urll(a_list):
    x = 0
    for i in a_list:
        url = re.findall(r'<a href="//(.+?)"', str(i))  #两个网址
        try:
            url_list.append(url[1])
        except:
            url_list.append(" ")
        x +=1
    return url_list

def tt(a_list):
    x = 0
    for i in a_list:
        # time.sleep(1)
        type_and_title = re.findall(r'l">(.+?)</a', str(i))
        tt_list.append(type_and_title)
        try:
            type.append(tt_list[x][0])
        except:
            type.append(" ")
        try:
            title.append(tt_list[x][1])
        except:
            title.append(" ")
        x += 1
    return tt_list

def ABC():
    db = pymysql.connect(host='localhost',user='root',password='123456',database='minisql')
    cur = db.cursor()
    keyword = "灾害"
    key_code = urllib.request.quote(keyword)
    page_number = 1
    while page_number<2:
        # url = r'''http://search.sina.com.cn/?c=img&q='''+key_code+"&ie=gbk&ps=&pf=&page="+str(page_number)
        url = 'http://www.chinanews.com/scroll-news/news1.html'
        try:
            a_list = getHtml(url)
            url_list = urll(a_list)
            tt_list = tt(a_list)

        except:
            break


        # for i in range(len(url_list)):
        #     sql = "insert into a1 value ( %s)"
        #     parm = (url_list[i])
        #     print(url_list[i])
        #
        #     try:
        #         cur.execute(sql,parm)
        #         db.commit()
        #     except:
        #         db.rollback()
        # cur.close()

        for i in range(len(tt_list)):
            sql = "insert into a4 value (%s,%s)"
            try:
                parm = str(i)+(tt_list[i][0])
                parm2 = (tt_list[i][1])

                try:
                    cur.execute(sql,(parm,parm2))
                    db.commit()
                    print(i)
                    print('插入成功')

                except:
                    print('插入失败，数据回滚')
                    db.rollback()

            except:
                pass


        page_number +=1
    cur.close()


if __name__ == '__main__':
    ABC()