import requests
import urllib
from bs4 import BeautifulSoup as BS
from lxml import html
etree = html.etree
import re
import time
import scrapy
from qsbk.spiders.callui import MyMainWindow
import pymysql
import random
import eventlet
url_list = []
tt_list = []  # 类别和主题
type = []
title = []
class xinwen(scrapy.Spider):
    name = 'xinwen'
    # start_urls = ['http://www.chinanews.com/']
    start_urls = ['http://www.baidu.com/']

    def getHtml(self,url):
        '''爬取'''
        global url_list
        global tt_list   # 类别和主题
        global type
        global title
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
            'Referer': 'http: // sou.chinanews.com / imgsearch.do'
        }
        respons = requests.get(url, headers=headers)
        respons.encoding = 'utf-8'
        html = respons.text
        soup = BS(html, 'lxml')
        a_list = soup.select('#content_right > div.content_list > ul>li')
        x = 0
        for i in a_list:
            url = re.findall(r'<a href="//(.+?)"', str(i))  # 两个网址
            try:
                url_list.append(url[1])
            except:
                print('出错 了！！！！！！！')
                url_list.append(" ")
            x += 1
        print(url_list)
        x = 0
        for i in a_list:
            # time.sleep(1)
            type_and_title = re.findall(r'l">(.+?)</a', str(i))
            tt_list.append(type_and_title)
            try:
                type.append(tt_list[x][0])
            except:
                type.append(" ")
            try:
                title.append(tt_list[x][1])
            except:
                title.append(" ")
            x += 1
        print(tt_list)
        return html

    def parse(self, response):
        '''新闻'''
        keyword = '灾害'
        key_code = urllib.request.quote(keyword)
        page_number = 1
        while page_number < 2:
            url = 'http://www.chinanews.com/scroll-news/news' + str(page_number) + '.html'
            print(url)
            try:
                ''''''
                a_list = self.getHtml(url)

            except:
                print('出错了！')
                break
            db = pymysql.connect(host='localhost', user='root', password='123456', database='minisql')
            cur = db.cursor()
            for i in range(len(tt_list)):
                sql = "insert into a4 value (%s,%s)"
                try:
                    parm = str(random.randint(0,100000)) + (tt_list[i][0])
                    parm2 = (tt_list[i][1])


                    try:
                        print("尝试插入"+parm, parm2)
                        cur.execute(sql, (parm, parm2))
                        db.commit()
                        print('插入成功')
                    except:
                        print('插入失败，数据回滚')
                        db.rollback()
                except:
                    pass
            cur.close()

            page_number += 1

