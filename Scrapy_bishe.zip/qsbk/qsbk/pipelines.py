from openpyxl import Workbook

class QsbkPipeline(object):

    def __init__(self):
        self.line = 0
        self.wb = Workbook()
        self.ws = self.wb.active
        self.ws.append(["风景名称","图片来源","风景简介"])

    def open_spider(self,spider):
        self.line=1

    def process_item(self, item, spider):
        if spider.name == 'qsbk2':
            line = [item['title'],item['picture'],item['content']]
            self.ws.append(line)
            self.wb.save('风景4.xlsx')#这里改生成表格名字
            return item

    def close_spider(self,spider):
        self.line=2

class baidupip(object):
    def process_item(self,item,spider):
        if spider.name == 'baidu':
            print("pip")

class weibopip(object):
    def process_item(self,item,spider):
        if spider.name == 'weibo':
            print('pip')

class xinwenpip(object):
    def process_item(self,item,spider):
        if spider.name == 'xinwen':
            print('pip')